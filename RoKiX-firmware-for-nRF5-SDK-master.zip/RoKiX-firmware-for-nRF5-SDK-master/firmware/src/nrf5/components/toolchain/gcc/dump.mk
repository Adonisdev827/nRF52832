$(info $($(VARIABLE)))
all: ;
