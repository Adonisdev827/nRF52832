package com.moko.bxp.nordic;

public class AppConstants {
    // data time pattern
    public static final String PATTERN_HH_MM = "HH:mm";
    public static final String PATTERN_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String PATTERN_MM_DD = "MM/dd";
    public static final String PATTERN_MM_DD_2 = "MM-dd";
    public static final String PATTERN_YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
    public static final String PATTERN_YYYY_MM_DD_HH_MM_SS = "dd/MM/yyyy HH:mm:ss";
    // sp
    public static final String SP_NAME = "sp_name_beaconx_pro";

    public static final String SP_KEY_DEVICE_ADDRESS = "sp_key_device_address";
    // extra_key
    // 设备列表
    public static final String EXTRA_KEY_RESPONSE_ORDER_TYPE = "EXTRA_KEY_RESPONSE_ORDER_TYPE";
    public static final String EXTRA_KEY_SLOT_DATA = "EXTRA_KEY_SLOT_DATA";
    public static final String EXTRA_KEY_PASSWORD = "EXTRA_KEY_PASSWORD";
    public static final String EXTRA_KEY_DEVICE_TYPE = "EXTRA_KEY_DEVICE_TYPE";
    public static final String EXTRA_KEY_TRIGGER_TYPE = "EXTRA_KEY_TRIGGER_TYPE";
    public static final String EXTRA_KEY_TRIGGER_DATA = "EXTRA_KEY_TRIGGER_DATA";
    public static final String EXTRA_KEY_TAMPER_DETECT = "EXTRA_KEY_TAMPER_DETECT";
    public static final String EXTRA_KEY_NO_SINGLE_TRIGGER = "EXTRA_KEY_NO_SINGLE_TRIGGER";
    public static final String EXTRA_KEY_PASSWORD_VERIFICATION = "EXTRA_KEY_PASSWORD_VERIFICATION";
    public static final String EXTRA_KEY_SLOT_ENABLE = "EXTRA_KEY_SLOT_ENABLE";
    public static final String EXTRA_KEY_DEVICE_MAC = "EXTRA_KEY_DEVICE_MAC";
    public static final String EXTRA_KEY_DEVICE_NAME = "EXTRA_KEY_DEVICE_NAME";
    public static final String IS_NEW_VERSION = "IS_NEW_VERSION";

    // request_code
    public static final int REQUEST_CODE_DEVICE_INFO = 0x10;
    public static final int REQUEST_CODE_SLOT_DATA = 100;
    public static final int REQUEST_CODE_ENABLE_BT = 1001;
    public static final int REQUEST_CODE_QUICK_SWITCH = 1002;


    public static final int REQUEST_CODE_PERMISSION = 120;
    public static final int REQUEST_CODE_PERMISSION_2 = 121;
    public static final int REQUEST_CODE_LOCATION_SETTINGS = 122;
    public static final int PERMISSION_REQUEST_CODE = 1;

    // result_code
    public static final int RESULT_CONN_DISCONNECTED = 2;
}
